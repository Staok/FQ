#### 此教程适用于没有美区AppleID的网友；如果有的话，可以直接上AppStore下载Potatso Lite

### 步骤如下：

#### 1. 下载Shadowrocket IPA文件
&nbsp;&nbsp; 点击下载 [Shadowrocket](https://raw.githubusercontent.com/Cowan97/Shadowrocket/master/Shadowrocket-2.1.11.ipa)

#### 2. 使用爱思助手给手机安装Shadowrocket 
1. 在电脑上安装爱思助手 https://www.i4.cn/
2. 将iPhone通过USB连接到电脑
3. 在电脑上双击下载好的ipa文件，将shadowrocket安装到手机上<br/>

[<img src="../blob/master/resources/iphone/ss_01.PNG?raw=true" width="400px"/>](../blob/master/resources/iphone/ss_01.PNG?raw=true) 
--
[<img src="../blob/master/resources/iphone/ss_02.PNG?raw=true" width="400px"/>](../blob/master/resources/iphone/ss_02.PNG?raw=true) 

#### 3. 获取Shadowsocks账号
&nbsp;&nbsp; 前往 https://github.com/gfw-breaker/ssr-accounts

#### 4. 添加Shadowsocks账号
1. 添加节点，填写IP地址、端口、密码及加密协议，点击完成回到首页
2. 选中刚添加的节点，点击右上角开关，连接，点击Allow允许添加VPN配置
3. 成功连接后，屏幕上方会有vpn字样图标 <br/>

[<img src="../blob/master/resources/iphone/ss_03.jpg?raw=true" width="220px"/>](../blob/master/resources/iphone/ss_03.jpg?raw=true)
[<img src="../blob/master/resources/iphone/ss_04.jpg?raw=true" width="220px"/>](../blob/master/resources/iphone/ss_04.jpg?raw=true) 
[<img src="../blob/master/resources/iphone/ss_05.jpg?raw=true" width="220px"/>](../blob/master/resources/iphone/ss_05.jpg?raw=true) 
  

#### 视频教程：https://www.youtube.com/watch?v=xAgx5vdPw8o
#### 免翻墙浏览禁闻和精彩视频 [禁闻聚合](https://github.com/gfw-breaker/banned-news/blob/master/README.md)

<img src='http://gfw-breaker.win/guides.md' width='0px' height='0px'/>