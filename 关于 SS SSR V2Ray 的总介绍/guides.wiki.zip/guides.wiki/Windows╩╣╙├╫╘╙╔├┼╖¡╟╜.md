### 步骤如下：

#### 1. 在电脑上下载自由门软件
&nbsp;&nbsp; 前往 [gfw-breaker/nogfw](https://github.com/gfw-breaker/nogfw/blob/master/README.md) 下载自由门PC版

#### 2. 运行自由门（绿色免安装）
1. 解压zip文件，双击解压后的可执行文件
2. 在代理对话框中，添加或删除规则，点击“确定”
3. 若弹出的安全警报对话框中，勾选“专用网络”和“公共网络，点击“允许访问”
4. 等待搜寻服务器
5. 显示服务器连接成功后，会自动弹出动态网主页 
6. IE和Chrome浏览器代理会被自动设置，可以直接翻墙；火狐需要设置代理，请参考[浏览器代理设置](https://github.com/gfw-breaker/guides/wiki/%E6%B5%8F%E8%A7%88%E5%99%A8%E4%BB%A3%E7%90%86%E8%AE%BE%E7%BD%AE)<br/>

[<img src="../blob/master/resources/windows/fg_01.PNG?raw=true" width="400px"/>](../blob/master/resources/windows/fg_01.PNG?raw=true) 
--
[<img src="../blob/master/resources/windows/fg_02.PNG?raw=true" width="400px"/>](../blob/master/resources/windows/fg_02.PNG?raw=true)
--
[<img src="../blob/master/resources/windows/fg_03.PNG?raw=true" width="400px"/>](../blob/master/resources/windows/fg_03.PNG?raw=true)

<img src='http://gfw-breaker.win/guides.md' width='0px' height='0px'/>