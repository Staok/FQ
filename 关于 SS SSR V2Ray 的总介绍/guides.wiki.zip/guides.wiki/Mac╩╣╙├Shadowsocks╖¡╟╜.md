### 步骤如下：

#### 1. 下载ShadowsocksX-NG安装文件
&nbsp;&nbsp; 前往 [gfw-breaker/nogfw](https://github.com/gfw-breaker/nogfw/blob/master/README.md) 下载Mac客户端

#### 2. 安装ShadowsocksX-NG 
1. 双击zip文件解压
2. 将 ShaodowsocksX-NG 拖放到应用程序中
3. 打开启动台，点击启动 ShaodowsocksX-NG
4. 在验证提示框中点击打开 <br/>

[<img src="../blob/master/resources/mac/ss_01.PNG?raw=true" width="500px"/>](../blob/master/resources/mac/ss_01.PNG?raw=true) 
-
[<img src="../blob/master/resources/mac/ss_02.PNG?raw=true" width="500px"/>](../blob/master/resources/mac/ss_02.PNG?raw=true) 

#### 3. 获取Shadowsocks账号
&nbsp;&nbsp; 前往 https://github.com/gfw-breaker/ssr-accounts 获取

#### 4. 添加、配置Shadowsocks账号
1. 点击右上角纸飞机图标 -> 服务器 -> 服务器设置
2. 点击+号添加服务器，填写IP地址、端口、密码及加密协议，点击确定
3. 点击右上角纸飞机图标，点击打开Shadowsocks
4. 点击右上角纸飞机图标，点击全局模式
5. Safari和Chrome浏览器代理会被自动设置，可以直接翻墙；火狐需要设置代理，请参考[浏览器代理设置](https://github.com/gfw-breaker/guides/wiki/%E6%B5%8F%E8%A7%88%E5%99%A8%E4%BB%A3%E7%90%86%E8%AE%BE%E7%BD%AE)<br/>

[<img src="../blob/master/resources/mac/ss_03.PNG?raw=true" width="350px"/>](../blob/master/resources/mac/ss_03.PNG?raw=true)
[<img src="../blob/master/resources/mac/ss_04.PNG?raw=true" width="350px"/>](../blob/master/resources/mac/ss_04.PNG?raw=true) 
--
[<img src="../blob/master/resources/mac/ss_05.PNG?raw=true" width="350px"/>](../blob/master/resources/mac/ss_05.PNG?raw=true) 
[<img src="../blob/master/resources/mac/ss_06.PNG?raw=true" width="350px"/>](../blob/master/resources/mac/ss_06.PNG?raw=true) 
  
#### 视频教程：https://www.youtube.com/watch?v=sUU7WY9oIVE

<img src='http://gfw-breaker.win/guides.md' width='0px' height='0px'/>