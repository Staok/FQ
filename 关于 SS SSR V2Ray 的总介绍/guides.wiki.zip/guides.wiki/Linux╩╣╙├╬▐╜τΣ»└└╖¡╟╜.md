### 步骤如下：

#### 1. 下载无界Linux版
&nbsp;&nbsp; a. 打开Terminal，执行 `wget https://raw.githubusercontent.com/gfw-breaker/nogfw/master/binary/ul` 下载<br/>
&nbsp;&nbsp; b. 或打开浏览器，前往 [gfw-breaker/nogfw](https://github.com/gfw-breaker/nogfw/blob/master/README.md) 下载无界Linux版 

#### 2. 运行无界
1. 打开Terminal，进入到无界软件所在目录
2. 执行 `chmod +x ul` 添加可执行权限
3. 执行 `sudo ./ul` 运行无界
4. 等待搜寻服务器
5. 服务器连接成功后，会有 "CONNECTED" 字样输出 <br/>

[<img src="../blob/master/resources/linux/ul_01.PNG?raw=true" width="400px"/>](../blob/master/resources/linux/ul_01.PNG?raw=true)

#### 3. 设置浏览器代理
&nbsp;&nbsp; 无界代理地址为 127.0.0.1，端口为9666。设置方法请参考[浏览器代理设置](https://github.com/gfw-breaker/guides/wiki/%E6%B5%8F%E8%A7%88%E5%99%A8%E4%BB%A3%E7%90%86%E8%AE%BE%E7%BD%AE) <br/>

[<img src="../blob/master/resources/linux/ul_02.PNG?raw=true" width="400px"/>](../blob/master/resources/linux/ul_02.PNG?raw=true)

<img src='http://gfw-breaker.win/guides.md' width='0px' height='0px'/>