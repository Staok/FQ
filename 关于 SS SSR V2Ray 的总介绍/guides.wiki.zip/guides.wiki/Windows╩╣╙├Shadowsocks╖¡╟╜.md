### 步骤如下：

#### 1. 在电脑上下载SS客户端
&nbsp;&nbsp; 前往 [gfw-breaker/nogfw](https://github.com/gfw-breaker/nogfw/blob/master/README.md) 下载Windows客户端

#### 2. 获取Shadowsocks账号
&nbsp;&nbsp; 前往 https://github.com/gfw-breaker/ssr-accounts 获取

#### 3. 运行Shadowsocks客户端
1. 解压zip文件，双击解压后的Shadowsocks程序
2. 在弹出的编辑服务器对话框中填写IP地址、端口、密码及加密协议，点击确定
3. 点击右下角纸飞机图标，点击 系统代理 -> 全局模式 <br/>
4. IE和Chrome浏览器代理会被自动设置，可以直接翻墙；火狐需要设置代理，请参考[浏览器代理设置](https://github.com/gfw-breaker/guides/wiki/%E6%B5%8F%E8%A7%88%E5%99%A8%E4%BB%A3%E7%90%86%E8%AE%BE%E7%BD%AE)<br/>

[<img src="../blob/master/resources/windows/ss_01.PNG?raw=true" width="400px"/>](../blob/master/resources/windows/ss_01.PNG?raw=true) 
--
[<img src="../blob/master/resources/windows/ss_02.PNG?raw=true" width="240px"/>](../blob/master/resources/windows/ss_02.PNG?raw=true) 

<img src='http://gfw-breaker.win/guides.md' width='0px' height='0px'/>