### 步骤如下：

#### 1. 下载Shadowsocks安卓客户端
&nbsp;&nbsp; 前往[gfw-breaker/nogfw](https://github.com/gfw-breaker/nogfw)下载安卓客户端

#### 2. 安装Shadowsocks客户端 
&nbsp;&nbsp; 点击已下载的APK文件，在弹出对话框中点击安装

#### 3. 获取Shadowsocks账号
&nbsp;&nbsp; 前往 https://github.com/gfw-breaker/ssr-accounts

#### 4. 添加Shadowsocks账号
1. 打开Shadowsocks，删除样本配置文件
2. 点击右上角+号添加新账号，填写IP地址、端口、密码及加密协议，点击勾图标回到首页
3. 选中刚添加的节点，点击下方的纸飞机图标
4. 在弹出的网络连接请求对话框中，点击确定允许添加VPN配置
3. 成功连接后，屏幕上方会纸飞机图标 <br/>

[<img src="../blob/master/resources/android/ss_01.png?raw=true" width="220px"/>](../blob/master/resources/android/ss_01.png?raw=true)
[<img src="../blob/master/resources/android/ss_02.png?raw=true" width="220px"/>](../blob/master/resources/android/ss_02.png?raw=true) 
[<img src="../blob/master/resources/android/ss_03.png?raw=true" width="220px"/>](../blob/master/resources/android/ss_03.png?raw=true) 

#### 视频教程：https://www.youtube.com/watch?v=jdyEftB8TVA

<img src='http://gfw-breaker.win/guides.md' width='0px' height='0px'/>