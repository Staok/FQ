### 步骤如下：

#### 1. 在电脑上下载无界软件
&nbsp;&nbsp; 前往 [gfw-breaker/nogfw](https://github.com/gfw-breaker/nogfw/blob/master/README.md) 下载无界PC版

#### 2. 运行无界浏览（绿色免安装）
1. 解压zip文件，双击解压后的可执行文件
2. 若弹出的安全警告对话框，点击“运行”
3. 等待搜寻服务器
4. 显示服务器连接成功后，会自动弹出无界浏览主页 
5. IE和Chrome浏览器代理会被自动设置，可以直接翻墙；火狐需要设置代理，请参考[浏览器代理设置](https://github.com/gfw-breaker/guides/wiki/%E6%B5%8F%E8%A7%88%E5%99%A8%E4%BB%A3%E7%90%86%E8%AE%BE%E7%BD%AE)<br/>

[<img src="../blob/master/resources/windows/u_02.PNG?raw=true" width="400px"/>](../blob/master/resources/windows/u_02.PNG?raw=true) 
--
[<img src="../blob/master/resources/windows/u_03.PNG?raw=true" width="400px"/>](../blob/master/resources/windows/u_03.PNG?raw=true)

<img src='http://gfw-breaker.win/guides.md' width='0px' height='0px'/>