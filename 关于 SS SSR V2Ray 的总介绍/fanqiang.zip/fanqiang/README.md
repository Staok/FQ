# 科学上网
SSR & V2ray 等免费账号及订阅地址分享和推荐，各种实用网站和软件分享。 此页面仅作学习交流用，请用于查找资料，不要做任何违法行为。所有资源均来自互联网，非盈利目的，仅供大家交流学习使用，出现一切问题概不负责。

一、SSR

(一)SSR免费节点订阅地址(直接复制链接地址粘贴到订阅地址里即可)

https://raw.githubusercontent.com/ssrsub/ssr/master/ssrsub

https://yzzz.ml/freessr/

https://raw.githubusercontent.com/AmazingDM/sub/master/ssrshare.com

https://haobang.yangwang.workers.dev/

http://www.yangwang.tk/

https://shadow-socks-share.herokuapp.com/subscribe

https://www.liesauer.net/yogurt/subscribe?ACCESS_TOKEN=DAYxR3mMaZAsaqUb

https://qiaomenzhuanfx.netlify.com/

https://muma16fx.netlify.com/

https://raw.githubusercontent.com/voken100g/AutoSSR/master/online

https://raw.githubusercontent.com/voken100g/AutoSSR/master/recent

https://youlianboshi.netlify.com/

http://ss.pythonic.life/full/subscribe




(二)免费SSR账号
推荐网站1：https://www.youneed.win/free-ssr

推荐网站2：http://nulastudio.org/Freedom/

推荐网站3：https://lncn.org/

推荐网站4：https://jichangdaquan.com/node/429.html

推荐网站5：https://www.freess.best/

推荐网站6：https://fanqiang.network/

推荐网站7：https://jichangdaquan.com/node/429.html




二、V2ray

(一)v2ray免费节点订阅地址(直接复制链接地址粘贴到订阅地址里即可)

二爷：https://jiang.netlify.com/

油脸博士: https://youlianboshi.netlify.com/

kitsunebi：https://raw.githubusercontent.com/eycorsican/rule-sets/master/kitsunebi_sub

https://raw.githubusercontent.com/ssrsub/ssr/master/v2ray

https://raw.githubusercontent.com/ntkernel/lantern/master/vmess_base64.txt

https://raw.githubusercontent.com/AmazingDM/sub/master/v2ray_ssrshare.com

(二)V2ary免费节点

1、推荐网站

推荐网站1：https://free-ss.site/

推荐网站2：https://www.freess.best/v2ray.html

推荐网站3：https://www.freevpnnet.com/

推荐网站4：https://jichangdaquan.com/node/429.html

推荐网站5：https://view.freev2ray.org/

推荐网站6：https://v2ray.cat/

推荐网站7：https://v2ray.party/

推荐网站8：https://my.freev2ray.org/

推荐网站9：https://v2fire.tk/

推荐网站10：https://get.freev2ray.com/

推荐网站11：https://freev2.org

推荐网站12：https://jichangdaquan.com/node/429.html


三、proxy代理科学上网

(一)proxy代理网站：
http://free-proxy.cz/en/

https://premproxy.com/list/

http://spys.one/

http://www.live-socks.net/





以上内容来源：
内容来源1：https://bhqt.ltd

内容来源2：https://github.com/hoochanlon/w3-goto-world/tree/master/%E7%A7%91%E5%AD%A6%E4%B8%8A%E7%BD%91%E3%80%81%E6%9A%97%E7%BD%91%E3%80%81%E9%9B%B6%E7%BD%91/%E5%85%8D%E8%B4%B9ss%E3%80%81ssr%E3%80%81vmess%E5%88%86%E4%BA%AB

内容来源3：https://bhqt.ltd/?p=240

内容来源4：https://www.appmews.com/ssr/

内容来源5：https://fanqiang.network/shadowsocks-servers

内容来源6：https://github.com/ntkernel/lantern/blob/master/README.md









