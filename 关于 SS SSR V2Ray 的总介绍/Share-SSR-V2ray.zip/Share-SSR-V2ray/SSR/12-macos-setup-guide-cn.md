# ShadowsocksR 设置方法 (MacOS)

MacOS 的 SSR 使用方法同  [Shadowsocks 设置方法 (macOS)](../SS/3-macos-setup-guide-cn.md) 

