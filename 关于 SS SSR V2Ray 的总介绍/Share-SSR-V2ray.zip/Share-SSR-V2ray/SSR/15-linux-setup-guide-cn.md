# ShadowsocksR 设置方法 (Linux)

Linux 的 SSR 使用方法同   [Shadowsocks 设置方法 (Linux)](../SS/6-linux-setup-guide-cn.md) 

