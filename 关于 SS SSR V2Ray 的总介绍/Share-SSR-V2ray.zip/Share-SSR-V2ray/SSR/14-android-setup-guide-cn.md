# Android 下 ShadowsocksR 设置方法

## 1、下载客户端

您可以通过Github 直接[下载](<https://github.com/shadowsocksrr/shadowsocksr-android/releases>) .apk 文件进行安装

## 2、获取 ShadowsocksR 账号信息

详见 分享节点信息

## 3、配置 ShadowsocksR 客户端

配置方法同： [Android 下 Shadowsocks 设置方法#配置 Shadowsocks 客户端](../SS/5-android-setup-guide-cn.md#配置 Shadowsocks 客户端) 

