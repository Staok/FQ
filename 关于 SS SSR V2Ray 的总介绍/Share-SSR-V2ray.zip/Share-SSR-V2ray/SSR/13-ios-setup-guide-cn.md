# ShadowsocksR 设置方法 (iOS) 

IOS 的 SSR 使用方法同  [Shadowsocks 设置方法 (iOS)](../SS/4-ios-setup-guide-cn.md) 

