<h1>Just My Socks：搬瓦工官方翻墙服务，多条线路，IP不怕被墙</h1>

如果无法查看教程中的图片，可访问https://tr1.freeair888.club/just-my-socks

***

<h2>文章目录</h2>
<ol id="user-content-content-index-contents">
 	<li><a href="#user-content-just1">Just My Socks介绍</a></li>
 	<li><a href="#user-content-just2">Just My Socks购买</a></li>
 	<li><a href="#user-content-just3">Just My Socks优惠码</a></li>
 	<li><a href="#user-content-just4">Just My Socks注册</a></li>
 	<li><a href="#user-content-just5">Just My Socks信息查看</a></li>
 	<li><a href="#user-content-just6">Just My Socks怎么用</a></li>
</ol>
<p class="keepp">
Just My Socks是一个ss/ssr/v2ray服务商（机场），由搬瓦工官方推出，每个服务提供6条线路，包括最快的CN2 GIA线路。Just My Socks最大的优势是保证IP不被墙，如果IP被墙，会自动更换新的可用IP给用户。对于只是需要翻墙看看YouTube、ins或者谷歌以及谷歌学术的朋友，Just My Socks是一个非常合适的选择。除了Just My Socks，还可以考虑<a rel="nofollow" href="https://github.com/Alvin9999/new-pac/wiki/V2free%E6%9C%BA%E5%9C%BA">V2free机场</a>。
</p>
<h2 id="user-content-just1"><span id="just_my_socks">一、Just My Socks介绍</span></h2>
<p class="keepp">
<strong>Just My Socks靠谱吗？</strong>不同于其他机场，Just My Socks是搬瓦工官方推出的，已经稳定运行了近2年了（2018年10月推出的）。
</p>
<p class="keepp">
<strong>Just My Socks怎么样？</strong>线路优质，包括最快的搬瓦工CN2 GIA线路。
</p>
<p class="keepp">
<strong>哪些人适合用Just My Socks？</strong>不想自己搭建ss/ssr或v2ray翻墙帐号，但又对速度有较高的要求，Just My Socks可以非常方便的达到这些需求。<strong>Just My Socks缺点</strong>：无法看Netflix。
</p>
<p class="keepp">
<strong>支持的协议：TCP或UDP？</strong>
Just My Socks 100仅支持TCP协议，该协议足以用于浏览网络以及使用YouTube等大多数流媒体服务。从Just My Socks 500开始的所有套餐均支持TCP和UDP协议（请参阅下面的注释）。语音协议（如WhatsApp和某些VOIP实现）可能需要UDP协议。如果您的套餐是Just My Socks 100，并且您想使用UDP协议，那么您将需要升级到Just My Socks 500套餐。
</p>
<h2 id="user-content-just2"><span id="just_my_socks-2">二、Just My Socks购买</span></h2>
<p class="keepp">目前，Just My Socks一共有4种方案：</p>
<table id="tablepress-1">
<thead>
<tr>
<th>方案名称</th>
<th>带宽</th>
<th>流量</th>
<th>价格</th>
<th>设备限制</th>
<th>购买链接</th>
</tr>
</thead>
<tbody>
<tr>
<td>Just My Socks 100</td>
<td>1 GB</td>
<td>100 GB /月</td>
<td>$2.88 / 月</td>
<td>最多3个设备同时在线(当前断货)</td>
<td><a rel="nofollow" href="https://justmysocks3.net/members/aff.php?aff=8225&pid=1">立即购买</a></td>
</tr>
<tr>
<td>Just My Socks 500</td>
<td>2.5 GB</td>
<td>500 GB / 月</td>
<td>$5.88 / 月</td>
<td>最多5个设备同时在线</td>
<td><a rel="nofollow" href="https://justmysocks3.net/members/aff.php?aff=8225&pid=2">立即购买</a></td>
</tr>
<tr>
<td>Just My Socks 1000</td>
<td>5 GB</td>
<td>1TB / 月</td>
<td>$9.88 / 月</td>
<td>不限制设备数量</td>
<td><a rel="nofollow" href="https://justmysocks3.net/members/aff.php?aff=8225&pid=3">立即购买</a></td>
</tr>
<tr>
<td>Just My Socks 5000</td>
<td>5 GB</td>
<td>5TB / 月</td>
<td>$48.99 / 月</td>
<td>不限制设备数量</td>
<td><a rel="nofollow" href="https://justmysocks3.net/members/aff.php?aff=8225&pid=4">立即购买</a></td>
</tr>
</tbody>
</table>
<p class="keepp">
<strong>我该选择哪一款Just My Socks？</strong>一般来说，如果只是谷歌查资料，直接选择最便宜的方案就行，如果你爱看视频，并且非常频繁，那么就选择500或者1000的，需要注意的是<span style="color: #ff0000;">便宜方案都有设备限制</span>，如果你想多个人一起用，那么建议选择1000的，不限制设备数量。
</p>
<p class="keepp">
选择合适的Just My Socks方案后，点击“立即购买”进入购买页，确认配置无误后，点击Continue继续：
<br class="keepp">
Just My Socks 官网：<a rel="nofollow" href="https://justmysocks3.net/members/aff.php?aff=8225&gid=1">Just My Socks 官网</a>
</p>
<a href="https://github.com/killgcd/justmysocks/blob/master/images/jms-1.png" target="_blank" rel="noopener noreferrer"><img style="max-width:100%" src="https://github.com/killgcd/justmysocks/raw/master/images/jms-1.png" alt="Just My Socks 购买教程" /></a>
<h2 id="user-content-just3"><span id="just_my_socks-3">三、Just My Socks优惠码</span></h2>
<p class="keepp">
在购买Just My Socks时，我们可以使用Just My Socks优惠码：<strong>JMS9272283</strong>获取5.2%循环优惠，输入优惠码后点击Validate Code即可使用优惠码，点击Checkout付款：
<br class="keepp">
<a href="https://github.com/killgcd/justmysocks/blob/master/images/jms-2.png" target="_blank" rel="noopener noreferrer"><img style="max-width:100%" src="https://github.com/killgcd/justmysocks/raw/master/images/jms-2.png" alt="Just My Socks优惠码" /></a>
</p>
<h2 id="user-content-just4"><span id="just_my_socks-4">四、Just My Socks注册</span></h2>
<p class="keepp">
这里需要填写你Just My Socks账号的信息：<strong>不要挂代理注册，如实填写</strong>，否则可能被认为欺诈，其中省份直接写拼音即可（例如Shandong），选择支付方式为Paypal（Paypal更安全）或 Alipay（支付宝），勾选同意服务条款后，点击Complete Order完成订单：
<br class="keepp">
<a href="https://github.com/killgcd/justmysocks/blob/master/images/jms-3.png" target="_blank" rel="noopener noreferrer"><img style="max-width:100%" src="https://github.com/killgcd/justmysocks/raw/master/images/jms-3.png" alt="Just My Socks 注册信息" /></a>
<br class="keepp">
用支付宝付款完成后，你的Just My Socks服务就购买完成了。
</p>
<h2 id="user-content-just5"><span id="just_my_socks-5">五、Just My Socks信息查看</span></h2>
<p class="keepp">
完成Just My Socks购买后，登陆<a rel="nofollow" href="https://justmysocks3.net/members/aff.php?aff=8225&gid=1">Just My Socks 官网</a>，选择Services-&gt;My Services，就可以看到你刚才买的服务了，点击这个服务查看详情：
<br class="keepp">
<a href="https://github.com/killgcd/justmysocks/blob/master/images/jms-4.png" target="_blank" rel="noopener noreferrer"><img style="max-width:100%" src="https://github.com/killgcd/justmysocks/raw/master/images/jms-4.png" alt="Just My Socks 我的服务" /></a>
</p>
<p class="keepp">
这里就可以看到shadowsocks和v2ray详情了（ip以域名形式发放，页面上也能看到域名对应的ip，如果域名解析不顺利可直接填入域名对应的ip）

**注意：默认的SS/SSR加密方式为aes-256-gcm，aes-256-gcm加密方式必须使用 SS 客户端，SSR客户端不支持aes-256-gcm。如果想用SSR客户端，在界面上操作一下就可以自动把aes-256-gcm加密方式改为SSR客户端支持的aes-256-cfb。**

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/softimag/just1.jpg)

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/softimag/just5.jpg)

加密方式修改如下图：

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/softimag/just6.jpg)

除了更改加密方式以外，还可以选择更改帐号密码和端口。

***

**第1～5条线路介绍**

cXs1，cXs2和cXs5通过CN2 GT网络与其他中国联通和中国移动直接连接进行路由。

服务器cXs3通过中国电信提供的CN2 GIA网络进行路由（仅中国电信路由）。

服务器cXs4通过高级中国移动混合路由（在返回路径上具有CN2 GIA）（仅中国移动路由）。

注意2020-08-11作为实验，某些cXs4服务器在返回路径上对所有3个运营商（CU / CM / CT）使用具有GIA支持的荷兰POP

**第6条线路：什么是Freedom服务器（s801）？**

Freedom服务器可以提供更多的数据传输，具体取决于当前的乘数。该服务器提供了较便宜的路由，并且不提供任何形式的保证。用它来节省您的每月数据传输津贴。

例如，如果当前数据传输倍数= 10，那么您下载的所有内容中只有1/10会计入每月数据配额。 

实际示例：假设您下载20GB的文件。如果您使用s1..s5范围内的服务器进行下载，则系统将计入所有20GB的数据传输（加上任何TCP开销）。
但是，如果您使用服务器s801进行此传输，并且当前乘数为10，则系统将仅占该传输的1/10（20 GB / 10 = 2 GB）

注意：数据传输乘数可以随时更改。官方不提供有关服务器s801的任何质量或正常运行时间保证。它是出于礼貌提供的，可以随时脱机使用。

**备注：上面是官方解释，简单点就是最后一条线路没有前面5条线路好，所以使用它时流量消耗会进行打折，相当于可以节省流量，但速度要慢点，主要取决于自己的需求。**

***


Windows SS客户端 [下载地址](https://github.com/shadowsocks/shadowsocks-windows/releases) 

[全平台SS/SSR客户端下载汇总](http://www.mediafire.com/folder/sfqz8bmodqdx5/shadowsocks相关客户端)

v2ray帐号可以参考这个教程来使用[v2ray各平台图文使用教程](https://github.com/Alvin9999/new-pac/wiki/v2ray%E5%90%84%E5%B9%B3%E5%8F%B0%E5%9B%BE%E6%96%87%E4%BD%BF%E7%94%A8%E6%95%99%E7%A8%8B) 

***

**注意：如果你感觉 Just My Socks 速度慢，觉得不满意，那你可以申请 Just My Socks 退款的！但退款需要满足以下所有条件：**

1、客户的账户信誉良好, 没有违反整个服务条款

2、以前没有任何付款或目前有争议

3、每月数据传输使用率低于 10％

4、该帐户是在7天内 或更短的时间前创建的

5、客户未使用其他账户退款的权利

退款按原付款方式退回。退款处理后, 帐户可用于未来订单, 但不再有退款资格。内容来自 Just My Socks 官方的 [Terms of Service ](https://justmysocks3.net/members/index.php?rp=/knowledgebase/1/Terms-of-Service.html)说明。

操作步骤：在 Just My Socks 官网菜单，选择 Services > My Services，然后会看到你已购买的产品信息，Status 显示 Active 的，即为当前可用的！

<a href="https://github.com/killgcd/justmysocks/blob/master/images/jms-4.png" target="_blank" rel="noopener noreferrer"><img style="max-width:100%" src="https://github.com/killgcd/justmysocks/raw/master/images/jms-4.png" alt="Just My Socks 我的服务" /></a>

点击进去之后，在左侧找到 Request Refund ，即是申请退款选项！如果你要退款，那就点击它！！！备注，你可能需要再点击一下类似 Request full refund for this service 的按钮。

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/softimag/just3.jpg)


退款方式是原路退回的，比如说你是使用了支付宝付款的，那么到时候也是退款到支付宝的。