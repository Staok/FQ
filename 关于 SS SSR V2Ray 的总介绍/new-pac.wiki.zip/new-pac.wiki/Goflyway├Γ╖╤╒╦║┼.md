## Goflyway免费账号/节点（长期更新）

### 翻墙后推荐网站：

google.com(谷歌；搜索类） dongtaiwang.com(动态网；新闻及网址导航类）  youtube.com(油管；视频类）  ntdtv.com(新唐人；视频新闻娱乐类）    epochtimes.com（大纪元；新闻类）   aboluowang.com(阿波罗新闻网；新闻类） bannedbook.org（禁书网；书籍类）   soundofhope.org（希望之声国际广播电台）  zh-cn.shenyun.com（神韵；文化艺术类） tuidang.org（三退保平安）


***

### 自己搭建服务器教程（SS、v2ray、brook、trojan、wireguard vpn） 

**图文教程，步骤详细，适合新手**

[自建ss/ssr服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAss%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建v2ray服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAv2ray%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建brook服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAbrook%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建trojan服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAtrojan%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建WireGuard VPN服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAWireGuard-VPN%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 

[一键搭建科学上网工具ProxySU](https://github.com/Alvin9999/new-pac/wiki/%E4%B8%80%E9%94%AE%E6%90%AD%E5%BB%BA%E7%A7%91%E5%AD%A6%E4%B8%8A%E7%BD%91%E5%B7%A5%E5%85%B7ProxySU)

VPS推荐：

[Vultr](https://www.vultr.com/?ref=7048874) （vps最低2.5美元/月，vultr全球17个服务器位置可选，包括日本、韩国、新加坡、洛杉矶、德国、荷兰等。支持支付宝和paypal付款。）

<a href="https://www.vultr.com/?ref=7048874"><img src="https://www.vultr.com/media/banners/banner_728x90.png" width="728" height="90"></a>

***

### 免费Goflyway节点/账号列表（长期更新）

**YouTube频道推荐**：   [新闻拍案惊奇-大宇](https://www.youtube.com/user/NTDEducation/videos)   [江峰时刻](https://www.youtube.com/channel/UCa6ERCDt3GzkvLye32ar89w/videos)  [文昭谈古论今](https://www.youtube.com/channel/UCtAIPjABiQD3qjlEl1T5VpA/featured) [天亮时分](https://www.youtube.com/channel/UCjvjNeHndz4PGs9JXhzdHqw/videos)  [新闻看点-李沐阳](https://www.youtube.com/channel/UCPMqbkR35zZV1ysWGXJPW-w/videos) [石濤TV-聚焦/NEWS](https://www.youtube.com/channel/UC6zxZTv5ZbMmEg5GqBmXAUQ/videos)  [阿波罗新闻网-热点直击](https://www.youtube.com/user/aboluowang/videos) [薇羽看世間](https://www.youtube.com/c/%E8%96%87%E7%BE%BD%E7%9C%8B%E4%B8%96%E9%96%93/videos)  [睿眼看世界](https://www.youtube.com/channel/UCcWBxfaO69GPOFHSArNET2Q/videos)  [真观点voices](https://www.youtube.com/c/%E7%9C%9F%E8%A7%82%E7%82%B9voices/videos)   [财经冷眼](https://www.youtube.com/c/%E8%B4%A2%E7%BB%8F%E5%86%B7%E7%9C%BC/videos) [文昭思绪飞扬](https://www.youtube.com/channel/UCTu_hTaVf3DJMpMIyOAq2Ew/videos) [老高与小茉](https://www.youtube.com/channel/UCMUnInmOkrWN4gof9KlhNmQ/videos) [NTD(中文)](https://www.youtube.com/user/NTDCHINESE/videos)  [NTD(英文)](https://www.youtube.com/c/ntdtv/videos)

**真相视频推荐**：天安门自焚事件真相——《伪火》[在线观看](http://cn.ntdtv.com/gb/2014/01/07/a24016.html) [本地观看&下载](http://video1.freeair777.club/%E4%BC%AA%E7%81%AB.mp4) 《九评》系列纪录片&文字版[在线观看](https://www.tuidang.org/9ping/)

***

**windows电脑系统的网友可以下载最新的自由门和无界，抗封锁性更强。自由门7.96版[下载地址1](https://tr101.free4444.xyz/fg796p.zip) [下载地址2](https://tr71.free4444.xyz/fg796p.zip) 无界21.20版[下载地址1](https://tr101.free4444.xyz/2120/u.zip) [下载地址2](https://tr71.free4444.xyz/2120/u.zip)**


**北京时间2021年6月23日20点32分更新节点。为了让每个人都能获得一定的带宽资源，节点进行了限速500kb/s。禁止使用节点进行BT下载、滥发垃圾邮件、DDOS攻击！BT下载会导致服务器被投诉版权而被封！如果不能看到最新的节点信息，把浏览器缓存清理一下。**

备用网址：http://tr1.freeair888.club/Goflyway免费账号 

***

IP：149.28.71.236

端口：12345

密码：dongtaiwang.com

客户端协议：HTTP

***


### Goflyway客户端下载：

**一、电脑版**

Goflyway Windows图形界面客户端 [下载地址1](https://tr61.free4444.xyz/Goflyway.7z) [下载地址2](https://tr21.free4444.xyz/Goflyway.7z) 操作方法和ss/ssr客户端类似。下载后解压出来，打开Goflyway文件夹里面的GoflywayTools.exe客户端，填写**上面最新的goflyway账号信息**后，点击“启动”按钮，浏览器代理设置成http 127.0.0.1 8100即可。

![](https://cdn.jsdelivr.net/gh/Alvin9999/PAC/goflyway/gy1.png)

![](https://cdn.jsdelivr.net/gh/Alvin9999/PAC/goflyway/goflyway-001.jpg)

**目前只有Windows图形界面的客户端，其它电脑系统，比如Mac、Linux要使用命令行来使用。**

***

Mac和Linux系统的电脑可以参考下面的**goflyway命令行**使用方法：

[下载命令行客户端](https://github.com/coyove/goflyway/releases)。

**如果账号是HTTP协议，用以下命令：**

启动命令：./goflyway -up="服务器地址:端口" -k="密码" -l=":8100"

Mac：cloudflare 里面 SSL/TLS 菜单里面关闭成off。

**如果账号是CDN协议，用以下命令：**

启动命令：./goflyway -up="cf://服务器地址:端口" -k="密码" -l=":8100"

Mac：cloudflare 里面 SSL/TLS 菜单里面 选上 Flexible，不要关闭成off。

**二、安卓版**

首先我们下载aligned-signed.apk[下载地址](https://github.com/coyove/goflyway/releases/download/2.0.0rc1/ss-align-signed.apk)

下载安装后继续。注意：因为 Goflyway 安卓客户端是基于 Shadowsocks 安卓客户端修改而来的，所以与 SS 客户端无法共存。

打开 Goflyway 安卓客户端后，可以看到一个默认的账号，因为 Goflyway 安卓客户端是基于 Shadowsocks 安卓客户端修改而来的，所以此处的默认账户实际上是 Shadowsocks 安卓客户端自带的 SS 账号，你只要删除或者修改该默认账户。

![](https://raw.githubusercontent.com/Alvin9999/pac2/master/goan2.png)

加密方式不能改，路由选项只能设置为：全局。但是"分应用"VPN 还是能用的，可以指定哪些应用走代理。

***

[其它翻墙方法](https://github.com/Alvin9999/new-pac/wiki/)

***

有问题可以发邮件至海外邮箱kebi2014@gmail.com