**2020年2月29日更新。**

原理是利用在线视频转换网站来解析YouTube视频地址，从而实现下载1080p视频的目的。

***

翻墙打开网址：https://www.y2mate.com/zh-cn2

图文教程如下：

![](https://cdn.jsdelivr.net/gh/Alvin9999/PAC/download/youtube下载5.png)

***

有问题或者更好的方法可以发邮件至海外邮箱kebi2014@gmail.com
