**2020年11月1日增加Mac使用Wine运行Windows软件教程。**

***

**第一种方法：利用SS/SSR账号翻墙上网**

[全平台SS/SSR客户端下载汇总](http://www.mediafire.com/folder/sfqz8bmodqdx5/shadowsocks相关客户端)

[点我获取最新免费ss或ssr账号](https://github.com/Alvin9999/new-pac/wiki/ss%E5%85%8D%E8%B4%B9%E8%B4%A6%E5%8F%B7)

具体步骤：

STEP1，下载用于MAC OS X的SHADOWSOCKSX软件 

**SSR客户端下载地址：** [下载地址](https://github.com/shadowsocksr-backup/ShadowsocksX-NG/releases) 
***

以SS客户端为例：

STEP2，打开下载的DMG文件，将程序图标拖到右边的APPLICATIONS，安装完成

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/MAC1.png)

STEP3，进入LAUNCHPAD，打开SHADOWSOCKSX,右上方出现程序图标，点击图标–“服务器”–“打开服务器设定”

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/MAC2.png)

STEP4，根据帐号信息，填写服务器地址（IP或者域名），端口，加密方式和密码，点确定

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/MAC3.png)

STEP5，选择刚刚配置好的服务器，点“打开SHADOWSOCKS”，DONE!

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/MAC4.png)

上面是使用SS客户端填写SS账号的方法，如果账号是SSR账号，使用SSR客户端时把协议和混淆填写好就可以了。

SSR客户端填写好SSR账号后，将浏览器代理设置成http 127.0.0.1和1080就可以用浏览器翻墙了。

**第二种方法：利用v2ray翻墙**

1、使用Mac客户端[v2rayX（第三方开发）](https://github.com/insisttech/v2rayX-copy/releases) 

2、使用Mac客户端[v2rayU（第三方开发）](https://github.com/yanue/V2rayU/releases)  

[点我获取免费v2ray账号](https://github.com/Alvin9999/new-pac/wiki/v2ray%E5%85%8D%E8%B4%B9%E8%B4%A6%E5%8F%B7)

使用方法参考[v2ray各平台图文使用教程](https://github.com/Alvin9999/new-pac/wiki/v2ray%E5%90%84%E5%B9%B3%E5%8F%B0%E5%9B%BE%E6%96%87%E4%BD%BF%E7%94%A8%E6%95%99%E7%A8%8B)

### 第三种方法：Mac使用Wine运行Windows软件

图文教程可参考：

[Mac使用Wine运行Windows软件](https://www.xiebruce.top/1077.html)

如果还有不清楚的地方，也可以自行搜素。当Mac可以用windows软件的时候，这样可选择的空间就很大。

***

有问题或者有更好的Mac软件分享，都可以发邮件到海外邮箱进行反馈kebi2014@gmail.com