## v2ray免费账号/节点（长期更新）

### 翻墙后推荐网站：

google.com(谷歌；搜索类） dongtaiwang.com(动态网；新闻及网址导航类）  youtube.com(油管；视频类）  ntdtv.com(新唐人；视频新闻娱乐类）    epochtimes.com（大纪元；新闻类）  aboluowang.com(阿波罗新闻网；新闻类） bannedbook.org（禁书网；书籍类）   soundofhope.org（希望之声国际广播电台）zh-cn.shenyun.com（神韵；文化艺术类）
 tuidang.org（三退保平安）
  

***

### 自己搭建服务器教程（SS、v2ray、brook、trojan、wireguard vpn） 

**图文教程，步骤详细，适合新手**

[自建ss/ssr服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAss%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建v2ray服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAv2ray%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建brook服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAbrook%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建trojan服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAtrojan%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建WireGuard VPN服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAWireGuard-VPN%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 

[一键搭建科学上网工具ProxySU](https://github.com/Alvin9999/new-pac/wiki/%E4%B8%80%E9%94%AE%E6%90%AD%E5%BB%BA%E7%A7%91%E5%AD%A6%E4%B8%8A%E7%BD%91%E5%B7%A5%E5%85%B7ProxySU) 

VPS推荐：

[Vultr](https://www.vultr.com/?ref=7048874) （vps最低2.5美元/月，vultr全球17个服务器位置可选，包括日本、韩国、新加坡、洛杉矶、德国、荷兰等。支持支付宝和paypal付款。）

<a href="https://www.vultr.com/?ref=7048874"><img src="https://www.vultr.com/media/banners/banner_728x90.png" width="728" height="90"></a>

***

### 免费v2ray账号/节点列表（长期更新）

**YouTube频道推荐**：  [新闻拍案惊奇-大宇](https://www.youtube.com/user/NTDEducation/videos)   [江峰时刻](https://www.youtube.com/channel/UCa6ERCDt3GzkvLye32ar89w/videos)  [文昭谈古论今](https://www.youtube.com/channel/UCtAIPjABiQD3qjlEl1T5VpA/featured) [天亮时分](https://www.youtube.com/channel/UCjvjNeHndz4PGs9JXhzdHqw/videos)  [新闻看点-李沐阳](https://www.youtube.com/channel/UCPMqbkR35zZV1ysWGXJPW-w/videos) [石濤TV-聚焦/NEWS](https://www.youtube.com/channel/UC6zxZTv5ZbMmEg5GqBmXAUQ/videos)  [阿波罗新闻网-热点直击](https://www.youtube.com/user/aboluowang/videos) [薇羽看世間](https://www.youtube.com/c/%E8%96%87%E7%BE%BD%E7%9C%8B%E4%B8%96%E9%96%93/videos)  [睿眼看世界](https://www.youtube.com/channel/UCcWBxfaO69GPOFHSArNET2Q/videos)  [真观点voices](https://www.youtube.com/c/%E7%9C%9F%E8%A7%82%E7%82%B9voices/videos)   [财经冷眼](https://www.youtube.com/c/%E8%B4%A2%E7%BB%8F%E5%86%B7%E7%9C%BC/videos) [文昭思绪飞扬](https://www.youtube.com/channel/UCTu_hTaVf3DJMpMIyOAq2Ew/videos) [老高与小茉](https://www.youtube.com/channel/UCMUnInmOkrWN4gof9KlhNmQ/videos) [NTD(中文)](https://www.youtube.com/user/NTDCHINESE/videos)  [NTD(英文)](https://www.youtube.com/c/ntdtv/videos)

**真相视频推荐**：天安门自焚事件真相——《伪火》[在线观看](http://cn.ntdtv.com/gb/2014/01/07/a24016.html) [本地观看&下载](http://video1.freeair777.club/%E4%BC%AA%E7%81%AB.mp4) 《九评》系列纪录片&文字版[在线观看](https://www.tuidang.org/9ping/)
 
***

**windows电脑系统的网友可以下载最新的自由门和无界，抗封锁性更强。自由门7.96版[下载地址1](https://tr101.free4444.xyz/fg796p.zip) [下载地址2](https://tr71.free4444.xyz/fg796p.zip) 无界21.20版[下载地址1](https://tr101.free4444.xyz/2120/u.zip) [下载地址2](https://tr71.free4444.xyz/2120/u.zip)**

**北京时间2021年6月27日9点10分更新VMESS节点。禁止使用节点进行BT下载、滥发垃圾邮件、DDOS攻击！BT下载会导致服务器被投诉版权而被封！如果不能看到最新的节点信息，把浏览器缓存清理一下。**


备用网址：http://tr1.freeair888.club/v2ray免费账号 

***

**复制节点后，右键点击任务栏v2rayN客户端图标，左键点击从剪贴板批量导入URL，即可一键导入所有v2ray节点。**

**VLESS节点**：

vless://56f88531-8d52-484c-a6be-3a78385d054a@104.18.0.50:443?encryption=none&security=tls&type=ws&host=nl2.free2222.xyz&path=%2fray#https%3a%2f%2fgithub.com%2fAlvin9999%2fnew-pac%2fwiki%2bVLESS%e8%8d%b7%e5%85%b0CDN

vless://3ead7294-b782-42e4-968c-f93ce3bfbdd6@1.1.1.0:443?encryption=none&security=tls&type=ws&host=v2rayge2.free3333.xyz&path=%2fray#https%3a%2f%2fgithub.com%2fAlvin9999%2fnew-pac%2fwiki%2bVLESS%e5%be%b7%e5%9b%bd


**注**：v2rayN客户端可以直接复制vless节点导入到客户端中，而其它客户端可能需要选择vless节点类型后手动填写信息。vless节点信息如下：


**VLESS节点1**：

Address(地址): 104.18.0.50

Port（端口）: 443

UUID（用户id）: 56f88531-8d52-484c-a6be-3a78385d054a

security（加密方式）: none

network（传输协议）: ws

headerType（伪装类型）: none

伪装域名（host）：nl2.free2222.xyz

路径：/ray

底层传输安全：tls

**VLESS节点2**：

Address(地址): 1.1.1.0

Port（端口）: 443

UUID（用户id）: 3ead7294-b782-42e4-968c-f93ce3bfbdd6

security（加密方式）: none

network（传输协议）: ws

headerType（伪装类型）: none

伪装域名（host）：v2rayge2.free3333.xyz

路径：/ray

底层传输安全：tls

**VMESS节点**：

vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogImh0dHBzOi8vZ2l0LmlvL3Y5OTk5IOaXpeacrOS4nOS6rExpbm9kZeaVsOaNruS4reW/gyAxIiwNCiAgImFkZCI6ICJhdXRvLmZyZWV2Mi50b3AiLA0KICAicG9ydCI6ICI1NTY0MSIsDQogICJpZCI6ICIyMTNmNjZjNi1kZjY4LTRiZGQtOGFkYi00MjRiYTA2YmJjM2UiLA0KICAiYWlkIjogIjEiLA0KICAibmV0IjogInRjcCIsDQogICJ0eXBlIjogIm5vbmUiLA0KICAiaG9zdCI6ICIiLA0KICAicGF0aCI6ICIiLA0KICAidGxzIjogIiIsDQogICJzbmkiOiAiIg0KfQ==

vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogImh0dHBzOi8vZ2l0LmlvL3Y5OTk5IOe+juWbveWKoOWIqeemj+WwvOS6muW3nua0m+adieeftlBldGFFeHByZXNzIDE1IiwNCiAgImFkZCI6ICIxOTguMi4yMDAuMjIwIiwNCiAgInBvcnQiOiAiNDQzIiwNCiAgImlkIjogIjJhMjNkYmQ1LTA5Y2YtNGFhOC1hODM1LTMyMzA3MjhjNDk3MyIsDQogICJhaWQiOiAiNjQiLA0KICAibmV0IjogIndzIiwNCiAgInR5cGUiOiAibm9uZSIsDQogICJob3N0IjogInd3dy40ODE2ODQ0My54eXoiLA0KICAicGF0aCI6ICIvcGF0aC8zMTA5MTAyMTE5MTYiLA0KICAidGxzIjogInRscyIsDQogICJzbmkiOiAiIg0KfQ==

vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogImh0dHBzOi8vZ2l0LmlvL3Y5OTk5IOe+juWbveWKoOWIqeemj+WwvOS6muW3nua0m+adieeftk1VTFRBQ09N5pWw5o2u5Lit5b+DIDEzIiwNCiAgImFkZCI6ICI5Ni40My45MS41OSIsDQogICJwb3J0IjogIjQ0MyIsDQogICJpZCI6ICIzYmZiNDNlMi03ZGZlLTQ3NTctODZlZS0xY2U5ZmI5ZmQxM2EiLA0KICAiYWlkIjogIjY0IiwNCiAgIm5ldCI6ICJ3cyIsDQogICJ0eXBlIjogIm5vbmUiLA0KICAiaG9zdCI6ICJ3d3cuNDUyMTg0NDMueHl6IiwNCiAgInBhdGgiOiAiL3BhdGgvMzEwOTEwMjExOTE2IiwNCiAgInRscyI6ICJ0bHMiLA0KICAic25pIjogIiINCn0=

vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogImh0dHBzOi8vZ2l0LmlvL3Y5OTk5IOe+juWbveaDoOaZrkhQIDIzIiwNCiAgImFkZCI6ICJ2Mi5saW5uLmluayIsDQogICJwb3J0IjogIjMwMDcwIiwNCiAgImlkIjogIjM5MzQxZmU3LWI4YjctNDYwNS1hODExLWFmMWYxZDQ2ZDRmYiIsDQogICJhaWQiOiAiMTAwIiwNCiAgIm5ldCI6ICJ0Y3AiLA0KICAidHlwZSI6ICJub25lIiwNCiAgImhvc3QiOiAiIiwNCiAgInBhdGgiOiAiIiwNCiAgInRscyI6ICIiLA0KICAic25pIjogIiINCn0=

vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogImh0dHBzOi8vZ2l0LmlvL3Y5OTk5IOe+juWbvUNsb3VkRmxhcmXlhazlj7hDRE7oioLngrkgMTMiLA0KICAiYWRkIjogIjEwNC4xOS43OS4yMDIiLA0KICAicG9ydCI6ICI0NDMiLA0KICAiaWQiOiAiYWEyMDllNTItOWJmYS00YzA1LTk2YjAtZTk2MmRhMmNiNDU3IiwNCiAgImFpZCI6ICIxIiwNCiAgIm5ldCI6ICJ3cyIsDQogICJ0eXBlIjogIm5vbmUiLA0KICAiaG9zdCI6ICJjLjE4MDguY2YiLA0KICAicGF0aCI6ICIveHJheXZ3cyIsDQogICJ0bHMiOiAidGxzIiwNCiAgInNuaSI6ICIiDQp9

vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogImh0dHBzOi8vZ2l0LmlvL3Y5OTk5IOiNt+WFsCAgMTgiLA0KICAiYWRkIjogIjQ2LjE4Mi4xMDcuMTU1IiwNCiAgInBvcnQiOiAiNDQzIiwNCiAgImlkIjogIjEzMGM5ZjJlLTQyYjEtNGViZi1iMzQ1LWUyNjExMWEwNjFmOSIsDQogICJhaWQiOiAiNjQiLA0KICAibmV0IjogIndzIiwNCiAgInR5cGUiOiAibm9uZSIsDQogICJob3N0IjogInd3dy41MzEwMzczOS54eXoiLA0KICAicGF0aCI6ICIvZm9vdGVycyIsDQogICJ0bHMiOiAidGxzIiwNCiAgInNuaSI6ICIiDQp9

**如果想搭建自己的v2ray节点，参考[自建v2ray服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAv2ray%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 。也可以考虑付费v2ray服务-[V2free机场](https://github.com/Alvin9999/new-pac/wiki/V2free%E6%9C%BA%E5%9C%BA)。**

***


### v2ray客户端下载及使用方法

windows客户端[v2rayN](https://github.com/2dust/v2rayN/releases/latest) 

Mac客户端[v2rayX](https://github.com/insisttech/v2rayX-copy/releases) 或 [v2rayU](https://github.com/yanue/V2rayU/releases)

Linux客户端[Qv2ray](https://github.com/lhy0403/Qv2ray/releases) 

安卓客户端v2ray vpn:[下载1](https://d1.w2rss.tk/ssvpn-universal.apk) 
[下载2](https://d2.w2rss.tk/ssvpn-universal.apk) 

iOS：[没有美区AppleID的翻墙教程](https://github.com/Alvin9999/new-pac/wiki/%E8%8B%B9%E6%9E%9C%E6%89%8B%E6%9C%BA%E7%BF%BB%E5%A2%99%E8%BD%AF%E4%BB%B6) [iOS注册美区Apple ID教程](https://github.com/Alvin9999/new-pac/wiki/iOS%E6%B3%A8%E5%86%8C%E7%BE%8E%E5%8C%BAApple-ID%E6%95%99%E7%A8%8B) 

使用方法参考[v2ray各平台图文使用教程](https://github.com/Alvin9999/new-pac/wiki/v2ray%E5%90%84%E5%B9%B3%E5%8F%B0%E5%9B%BE%E6%96%87%E4%BD%BF%E7%94%A8%E6%95%99%E7%A8%8B)

***

[其它翻墙方法](https://github.com/Alvin9999/new-pac/wiki/)

***

有问题可以发邮件至海外邮箱kebi2014@gmail.com