## SS/SSR免费账号/节点（长期更新）

### 翻墙后推荐网站：

google.com(谷歌；搜索类） dongtaiwang.com(动态网；新闻及网址导航类）  youtube.com(油管；视频类）  ntdtv.com(新唐人；视频新闻娱乐类）    epochtimes.com（大纪元；新闻类）  aboluowang.com(阿波罗新闻网；新闻类） bannedbook.org（禁书网；书籍类）   soundofhope.org（希望之声国际广播电台） zh-cn.shenyun.com（神韵；文化艺术类） tuidang.org（三退保平安）

***

### 自己搭建服务器教程（SS、v2ray、brook、trojan、wireguard vpn） 

**图文教程，步骤详细，适合新手**

[自建ss/ssr服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAss%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建v2ray服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAv2ray%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建brook服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAbrook%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建trojan服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAtrojan%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 
[自建WireGuard VPN服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAWireGuard-VPN%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B) 

[一键搭建科学上网工具ProxySU](https://github.com/Alvin9999/new-pac/wiki/%E4%B8%80%E9%94%AE%E6%90%AD%E5%BB%BA%E7%A7%91%E5%AD%A6%E4%B8%8A%E7%BD%91%E5%B7%A5%E5%85%B7ProxySU)

VPS推荐：

[Vultr](https://www.vultr.com/?ref=7048874) （vps最低2.5美元/月，vultr全球17个服务器位置可选，包括日本、韩国、新加坡、洛杉矶、德国、荷兰等。支持支付宝和paypal付款。）

<a href="https://www.vultr.com/?ref=7048874"><img src="https://www.vultr.com/media/banners/banner_728x90.png" width="728" height="90"></a>

***

### 免费SS/SSR账号/节点列表（长期更新）

**YouTube频道推荐**：   [新闻拍案惊奇-大宇](https://www.youtube.com/user/NTDEducation/videos)   [江峰时刻](https://www.youtube.com/channel/UCa6ERCDt3GzkvLye32ar89w/videos)  [文昭谈古论今](https://www.youtube.com/channel/UCtAIPjABiQD3qjlEl1T5VpA/featured) [天亮时分](https://www.youtube.com/channel/UCjvjNeHndz4PGs9JXhzdHqw/videos)  [新闻看点-李沐阳](https://www.youtube.com/channel/UCPMqbkR35zZV1ysWGXJPW-w/videos) [石濤TV-聚焦/NEWS](https://www.youtube.com/channel/UC6zxZTv5ZbMmEg5GqBmXAUQ/videos)  [阿波罗新闻网-热点直击](https://www.youtube.com/user/aboluowang/videos) [薇羽看世間](https://www.youtube.com/c/%E8%96%87%E7%BE%BD%E7%9C%8B%E4%B8%96%E9%96%93/videos)  [睿眼看世界](https://www.youtube.com/channel/UCcWBxfaO69GPOFHSArNET2Q/videos)  [真观点voices](https://www.youtube.com/c/%E7%9C%9F%E8%A7%82%E7%82%B9voices/videos)   [财经冷眼](https://www.youtube.com/c/%E8%B4%A2%E7%BB%8F%E5%86%B7%E7%9C%BC/videos) [文昭思绪飞扬](https://www.youtube.com/channel/UCTu_hTaVf3DJMpMIyOAq2Ew/videos) [老高与小茉](https://www.youtube.com/channel/UCMUnInmOkrWN4gof9KlhNmQ/videos) [NTD(中文)](https://www.youtube.com/user/NTDCHINESE/videos)  [NTD(英文)](https://www.youtube.com/c/ntdtv/videos)
 
**真相视频推荐**：天安门自焚事件真相——《伪火》[在线观看](http://cn.ntdtv.com/gb/2014/01/07/a24016.html) [本地观看&下载](http://video1.freeair777.club/%E4%BC%AA%E7%81%AB.mp4) 《九评》系列纪录片&文字版[在线观看](https://www.tuidang.org/9ping/)

***

**windows电脑系统的网友可以下载最新的自由门和无界，抗封锁性更强。自由门7.96版[下载地址1](https://tr101.free4444.xyz/fg796p.zip) [下载地址2](https://tr71.free4444.xyz/fg796p.zip) 无界21.20版[下载地址1](https://tr101.free4444.xyz/2120/u.zip) [下载地址2](https://tr71.free4444.xyz/2120/u.zip)**

**北京时间2021年6月22日13点04分新增2个莫斯科节点。为了让每个人都能获得一定的带宽资源，节点进行了限速500kb/s。禁止使用节点进行BT下载、滥发垃圾邮件、DDOS攻击！BT下载会导致服务器被投诉版权而被封！如果不能看到最新的节点信息，把浏览器缓存清理一下。**

备用网址：http://tr1.freeair888.club/ss免费账号 

***

<table id="tablepress-1">
<thead>
<tr>
<th>位置</th>
<th>地址</th>
<th>端口</th>
<th>密码</th>
<th>加密方式</th>
<th>协议</th>
<th>混淆</th>
</tr>
</thead>
<tbody>
<tr>
<td>德国</td>
<td>89.163.224.142</td>
<td>11208</td>
<td>dongtaiwang.com&nbsp;123abc</td>
<td>rc4</td>
<td>origin</td>
<td>plain</td>
</tr>
<tr>
<td>西雅图</td>
<td>173.0.55.68</td>
<td>22003</td>
<td>dongtaiwang.com&nbsp;123abc</td>
<td>rc4</td>
<td>origin</td>
<td>plain</td>
</tr>
<tr>
<td>莫斯科</td>
<td>ru001.free3333.xyz</td>
<td>443</td>
<td>dongtaiwang.com</td>
<td>none</td>
<td>auth_chain_a</td>
<td>tls1.2_ticket_auth</td>
</tr>
<tr>
<td>莫斯科</td>
<td>46.17.41.61</td>
<td>12345</td>
<td>dongtaiwang.com</td>
<td>aes-256-gcm</td>
<td>origin</td>
<td>plain</td>
</tr>
</tbody>
</table>

SSR节点一键导入地址：

ssr://ODkuMTYzLjIyNC4xNDI6MTEyMDg6b3JpZ2luOnJjNDpwbGFpbjpaRzl1WjNSaGFYZGhibWN1WTI5dElERXlNMkZpWXcvP29iZnNwYXJhbT0mcmVtYXJrcz01YjYzNVp1OVUxTlMmZ3JvdXA9YUhSMGNITTZMeTluYVhRdWFXOHZkams1T1Rr

ssr://MTczLjAuNTUuNjg6MjIwMDM6b3JpZ2luOnJjNDpwbGFpbjpaRzl1WjNSaGFYZGhibWN1WTI5dElERXlNMkZpWXcvP29iZnNwYXJhbT0mcmVtYXJrcz02S1dfNlp1RjVadS1VMU5TJmdyb3VwPWFIUjBjSE02THk5bmFYUXVhVzh2ZGprNU9UayZ1b3Q9MQ

ssr://cnUwMDEuZnJlZTMzMzMueHl6OjQ0MzphdXRoX2NoYWluX2E6bm9uZTp0bHMxLjJfdGlja2V0X2F1dGg6Wkc5dVozUmhhWGRoYm1jdVkyOXQvP29iZnNwYXJhbT0mcmVtYXJrcz02STZyNXBhdjU2ZVJVMU5TSzFSTVV5dERZV1JrZVEmZ3JvdXA9YUhSMGNITTZMeTluYVhRdWFXOHZkams1T1RrJnVvdD0x

ss://YWVzLTI1Ni1nY206ZG9uZ3RhaXdhbmcuY29tQDQ2LjE3LjQxLjYxOjEyMzQ1#https%3a%2f%2fgit.io%2fv9999+%e8%8e%ab%e6%96%af%e7%a7%91SS

**如果想搭建自己的ss/ssr节点，参考[自建ss/ssr服务器教程](https://github.com/Alvin9999/new-pac/wiki/%E8%87%AA%E5%BB%BAss%E6%9C%8D%E5%8A%A1%E5%99%A8%E6%95%99%E7%A8%8B)。或者考虑搬瓦工官方付费ss/ssr服务-[Just My Socks](https://github.com/Alvin9999/new-pac/wiki/Just-My-Socks) 或[V2free机场](https://github.com/Alvin9999/new-pac/wiki/V2free%E6%9C%BA%E5%9C%BA)。**

***


**SSR客户端下载：**

第一次电脑系统使用SSR/SS客户端时，如果提示你需要安装NET Framework 4.0，网上搜一下这个东西，安装一下即可。NET Framework 4.0是SSR/SS的运行库，没有这个SSR/SS客户端无法正常运行。有的电脑系统可能会自带NET Framework 4.0。

Windows SSR客户端 [下载地址](https://github.com/shadowsocksr-backup/shadowsocksr-csharp/releases) 

Windows SS客户端 [下载地址](https://github.com/shadowsocks/shadowsocks-windows/releases) 

Mac SSR客户端 [下载地址](https://github.com/shadowsocksr-backup/ShadowsocksX-NG/releases) 

Linux 客户端 [下载地址](http://www.mediafire.com/folder/xag0zy318a5tt/Linux) 

安卓SSR客户端 [下载地址](https://github.com/shadowsocksr-backup/shadowsocksr-android/releases/download/3.4.0.8/shadowsocksr-release.apk) 

iOS：[没有美区AppleID的翻墙教程](https://github.com/Alvin9999/new-pac/wiki/%E8%8B%B9%E6%9E%9C%E6%89%8B%E6%9C%BA%E7%BF%BB%E5%A2%99%E8%BD%AF%E4%BB%B6) [iOS注册美区Apple ID教程](https://github.com/Alvin9999/new-pac/wiki/iOS%E6%B3%A8%E5%86%8C%E7%BE%8E%E5%8C%BAApple-ID%E6%95%99%E7%A8%8B) 

[全平台SS/SSR客户端下载汇总](http://www.mediafire.com/folder/sfqz8bmodqdx5/shadowsocks相关客户端)

***

[其它翻墙方法](https://github.com/Alvin9999/new-pac/wiki/)

***

有问题可以发邮件至海外邮箱kebi2014@gmail.com