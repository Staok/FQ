[w1.v2free.net](https://w1.v2free.net/auth/register?code=UsUP)由海外人士运营，不存在关站风险，安全、可靠、稳定。

***

**介绍**

超低延迟、4k视频秒开、解锁流媒体。目前有38个v2ray节点，包括台湾、香港、韩国、日本、美国等。32个高速倍率节点，6个无限流量节点。

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/v2fee/v2ray-001.PNG)

**价格**

试用套餐3元、月付20元、年付经济套餐110元、年付A套餐168元、年付B套餐258元、年付C套餐338元，[套餐购买](https://w1.v2free.net/auth/register?code=UsUP)

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/v2fee/price01.PNG)

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/v2fee/price02.PNG)


***

**购买流程**

**先充值，然后购买相应的套餐，获取节点信息，复制节点或者订阅节点地址即可。**

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/v2fee/3.jpg)

**打开商店——充值进行充值，充值方式：微信、支付宝、paypal和数字货币。**

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/v2fee/v2ray-003.PNG)

**购买相应的套餐后，打开“用户中心”，在“快速使用”这里可以复制订阅链接以及所有节点信息，也可以在节点列表获取单个节点信息。**

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/v2fee/6.jpg)

![](https://cdn.jsdelivr.net/gh/Alvin9999/pac2/v2fee/8.jpg)

有任何问题都可以发工单进行咨询。